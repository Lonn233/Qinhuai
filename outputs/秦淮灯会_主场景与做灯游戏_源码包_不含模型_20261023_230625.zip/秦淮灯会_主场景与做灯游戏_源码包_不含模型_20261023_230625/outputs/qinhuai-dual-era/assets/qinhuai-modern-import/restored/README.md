# 原场景代理模型恢复

恢复日期：2026-10-20。来源：南京夫子庙秦淮河.max 引用的原始 .vrmesh；原文件未修改。

- 60 个原始代理资源，61 个网页模型变体，1546 个原始实例。
- 树木 84，灌木/绿化 1054，街边物件 329，人物 79；类别按资源整理，实例位置和变换来自原 MAX。
- 原 MAX 的父级变换、对象偏移、代理单位比例均已应用；坐标与现有主地图一致。
- 保留原材质颜色、漫反射贴图及透明遮罩。V-Ray 程序材质不等同于浏览器 PBR；没有漫反射贴图的材质使用原颜色，不误用其法线贴图。
- 树叶采用确定性的完整连通叶片抽样，枝干按几何误差降面；近距离叶片密度低于原离线模型。
- 浏览器按地图分区加载、共享几何/贴图并进行实例化；镜像实例单独修正面方向；不增加逐物件实时阴影。
- 总资源 41.38 MB，全量新增 3,880,867 三角面；未承诺特定设备帧率。
- 独立图层不读写建筑灯光或预设存储。

## 重建

在项目根目录依次运行：

1. Blender 后台运行 tools/extract-max-scene.py。
2. Blender 后台运行 tools/convert_missing_proxies.py。
3. node tools/optimize-restored-proxies.cjs。
4. node tools/build-import-viewer.cjs。

转换脚本使用 .json 旁路缓存；需要重新导出某个模型时，移开该模型生成的 .json，并移开 work/model-completeness-20261019/blender-prototypes 中对应的优化前 GLB；原资产无需改动。

## 验证

- node tools/test-restored-proxies.cjs：加载失败重试、并发去重、镜像变换、线框与资源释放。
- node tools/qa-restored-proxies.cjs：临时服务器与临时数据目录中的日夜浏览器验证，结果位于 work/restored-proxies-20261020。
- 原 MAX 提取流程已重跑，1546 个实例、187 个代理定义的参数和材质与首次提取完全一致。

离线 MAX 解析器的来源与 GPL 授权见 tools/vendor/io_scene_max/NOTICE.md 和 LICENSE；不包含在浏览器代码中。
