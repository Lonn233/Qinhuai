# 秦淮现代全场景独立导入资产

本目录由 `tools/convert_qinhuai_modern.py` 从源 FBX 转换生成。

- 运行页面：`/qinhuai-modern-import.html`
- 近景：`/qinhuai-modern-import.html?tile=near`
- 全部 tile：`/qinhuai-modern-import.html?tile=all`
- 性能信息：在地址后追加 `&perf=1`
- tile：5 个非空 GLB，纹理全部内嵌
- 原始场景：1,566 个网格、2,411,883 个顶点、3,339,067 个三角面
- 纹理：93 个修复，5 个缩放到 2048 上限，7 个源文件缺失

缺失的纹理名称记录在 `manifest.json` 和 `reports/import-report.json`。本目录不依赖原作者电脑路径。


## 龙墙材质修复（2026-10-17）

龙纹和宝珠的六个 FBX 网格原本没有材质连接（不是 HTTP 加载失败）。
已核对正面 UV，与源包 `FuziTemple0004.jpg` 的左龙和宝珠轮廓吻合；
另一条龙使用原模型镜像。修复保留所有坐标、顶点、法线和 UV，
仅为 `tile-05.glb` 的六个部件补配两种材质：正面为原照片彩纹，挤出侧面为哑光赭金色。
侧面颜色是补配，不声称找回了原始材质。
照片已内嵌到 GLB（2048×1208），部署不依赖外部源目录。其他七个丢失的贴图引用不在此次修复范围。

重新转换 FBX 后，在本工程根目录执行：

```powershell
python tools/repair_dragon_wall.py --textures "E:/soft/inspiration/灯会/model/秦淮现代地图/898689/FBX/Textures"
```

脚本只接受未绑定材质的六个准确网格名，已经修复时不重复修改。
详情见 `reports/dragon-wall-repair.json`。浏览器按 manifest 中的 tile revision 避免使用旧缓存。
龙墙位于 tile-05；近景模式只加载一个区域，需要点击“加载全部”才能保证包含龙墙。
