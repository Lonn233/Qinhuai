# 主场景近景半面数灯具

## 使用

在全秦淮地图的「地图调节 → 近景灯具模型」选择「Blender 半面数模型」。选择「现有轻量模型」即可恢复。独立偏好保存于 `qinhuai-near-lantern-quality-v1`，不修改场景存档。

临时指定可用主页面参数 `nearModels=half` / `nearModels=current`。

- 仅替换相机附近约 8 米内的灯具（按模型边界计算），退出距离带 15% 滞回，同时最多 12 盏。
- 默认不下载大模型；启用且靠近时按种类依次加载，加载期间或失败时继续使用原模型。
- 远处、摆放坐标、灯光颜色/亮度控制、反射效果网格及原 LOD 管理保持原样。
- 复用原场景材质、纹理；发布模型保留预览的几何、法线与 UV，不再次简化。
- 14 种已摆放资产接入。预览中的 hanging / crane 没有对应摆放，未擅自替换其他灯或添加摆放。

## 面数口径（重要）

这里的「半面数」是此前预览里 **原始高模经 Blender Decimate 0.5** 的结果，不是对当前运行时低模再减半。这些资产通常比原运行时轻量模型更精细，也更重。例如瑞狮半面数为 810,603 三角面，现有近景 LOD 为 89,996 三角面。此选项是画质选择，不承诺帧率提升。

## 生成与验证

- 生成：`python tools/prepare-near-lantern-half.py`（读取 `work/all-lanterns-half-preview`，原预览不改动）。
- `manifest.json` 记录各资产三角面、体积和来源/输出 SHA256。
- 构建：`node tools/build-import-viewer.cjs`。
- 单测：`node tools/test-near-lantern-quality.cjs`。
- 主场景浏览器测试：`node tools/test-near-lantern-main-browser.cjs`。
- 浏览器检查结果和截图：`work/near-lantern-quality/`。

测试只验证功能、材质复用和切换行为，不构成对照帧率基准。
