# 秦淮灯会源码包（不含模型）

## 打包范围与原文件保护

本包复制自原项目，保留原有相对目录和原文件内容；没有重新构建、替换或修改原项目源码。
包含主场景、两套做灯工坊、剧情与配音、界面图片、音乐音效、现有构建脚本、依赖锁文件、测试源码和设计文档。
由于项目同时存在两套独立工坊，为避免遗漏，本包同时保留，不替用户覆盖或合并版本。

## 入口

| 内容 | 相对包根目录的入口 |
| --- | --- |
| 主场景（秦淮地图、菜单、剧情） | `outputs/qinhuai-dual-era/qinhuai-modern-import.html` |
| 独立荷花灯工坊（hehua-workshop） | `outputs/qinhuai-dual-era/hehua-workshop/index.html` |
| 另一套第一人称制灯工坊（workshop） | `outputs/qinhuai-dual-era/lotus-workshop.html` |
| 工坊源代码 | `outputs/qinhuai-dual-era/hehua-workshop/` 与 `outputs/qinhuai-dual-era/workshop/` |
| 交互规范 | `交互终版.md` |
| 荷花灯工艺说明 | `做荷花灯.md` |
| 流程剧情整理 | `outputs/qinhuai-dual-era/游戏流程与剧情整理.md` |

## 运行方式

请先解压完整目录，再使用已安装 Node.js/npm 的环境运行。不要直接双击 HTML。

### 方式一：主场景及两套工坊共用服务

在解压后的包根目录打开 PowerShell：

```powershell
Set-Location -LiteralPath '.\outputs\qinhuai-dual-era'
npm ci
node game/serve.cjs
```

默认端口为 4180，分别打开：

- 主场景：`http://127.0.0.1:4180/qinhuai-modern-import.html`
- 独立荷花灯工坊：`http://127.0.0.1:4180/hehua-workshop/index.html`
- 另一套制灯工坊：`http://127.0.0.1:4180/lotus-workshop.html`

服务根地址默认是试灯室，不是主场景，请使用上述完整地址。`npm ci` 会从依赖仓库下载锁定版本，不包含在本源码包内。
端口被占用时，先执行 `$env:PORT=4188` 再启动，并相应修改浏览器地址。

### 方式二：仅启动独立荷花灯工坊

在解压后的包根目录打开 PowerShell：

```powershell
Set-Location -LiteralPath '.\outputs\qinhuai-dual-era'
node hehua-workshop/serve.cjs
```

打开 `http://127.0.0.1:4173/`。该目录原有的 `vendor/three.module.js` 和 `vendor/three.core.js` 一并保留。

## 已排除内容及重要限制

- 3D 模型文件与几何缓冲数据：包括 GLB、GLTF、FBX、OBJ、BLEND、BIN 等。
- 含内嵌模型的大型历史页面：原 `index.html`、`audit-baseline.html`、`pilot-LOD*.html`，没有修改或剥离这些原文件，而是整体不收入归档。
- `node_modules`、Git 历史、缓存、日志、开发中间产物、测试截图/报告、旧 ZIP、模型制作过程输出。
- 保留运行所需的非模型资源，包括 UI 图标、音效、配音、图片贴图、JSON 场景布局和模型资源索引；这些索引仍指向原模型路径，并不代表模型已被打包。
- 保留当前 `.local-data` 内的场景配置、灯具预设和恢复颜色配置（若原项目存在），不打包它们的历史、备份或浏览器快照。浏览器 localStorage 存档不在本包中。

**主场景依赖外部模型。此包是“不含模型的源码包”，并不是完整的离线成品游戏。未补齐模型时，场景可能加载失败、出现缺失资源或显示不完整，不能据此判断原游戏已损坏。**

运行完整主场景前，请将自有的模型文件按原相对路径补回（如 `outputs/qinhuai-dual-era/assets/`、`story/assets/`、`game/assets/` 以及项目运行目录中的 GLB）。具体排除路径见 `打包排除清单.json`。

已经保留原有 bundle 文件，不需要为了查看页面立即执行构建。构建模型相关页面仍需先补齐模型和对应工具依赖。

## 校验

- `源码文件校验清单.json`：每个复制文件的相对路径、字节数和 SHA-256。
- `打包排除清单.json`：选定交付目录内被排除的文件与原因。
- `打包验证报告.json`：ZIP 生成前的源码一致性和静态服务检查结果。

以上说明与校验文件仅新增在本打包副本内，不写回原源码目录。
